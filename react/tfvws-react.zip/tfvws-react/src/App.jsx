import React, { useState } from 'react';
import FindVerse from './components/SearchInputs/FindVerse/FindVerse';
import SearchText from './components/SearchInputs/SearchText/SearchText';
import PickCategory from './components/SearchInputs/PickCategory/PickCategory';
import './App.css';
import VerseListing from './Pages/VerseListing/VerseListing';
import VerseRelatedStory from './Pages/VerseRelatedStory/VerseRelatedStory';


function App() {

  const [verseData, setVerseData] = useState(null);
  const [verseSlug, setVerseSlug] = useState(null);

  console.log(verseSlug);

  return (
    <>
      <div className='appcontainer' >
        <FindVerse
          onVerseData={setVerseData}
        />
        <SearchText />
        <PickCategory />
      </div>
      <div>
        <VerseListing
          verseData={verseData}
          onVerseClick={setVerseSlug}
        />
        {verseSlug && (
          <VerseRelatedStory verseSlug={verseSlug} />
        )}
      </div>
    </>
  );
}

export default App;
