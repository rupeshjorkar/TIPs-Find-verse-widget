import React, { useState } from 'react';

import './FindVerse.css';
import tipsApi from '../../../api/tipsApi';

const FindVerse = ({ onVerseData }) => {

    const [findVerseInput, setFindVerseInput] = useState('');

    const handleFindVerse = async () => {
        if (!findVerseInput.trim()) return;
        const result = await tipsApi.findVerse(findVerseInput);
        onVerseData(result);
        setFindVerseInput(''); 
    };

  return (
    <div className="find-verse-group">
      <input
        type="text"
        placeholder="Tips: Find verse"
        value={findVerseInput}
        onChange={(e) => setFindVerseInput(e.target.value)}
      />
      <button className="btn-find-verse" onClick={handleFindVerse}>
        FIND VERSE
      </button>
    </div>
  );
};

export default FindVerse;