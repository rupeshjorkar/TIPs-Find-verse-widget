import React from 'react';
import './SearchText.css';

const SearchText = () => {
  return (
    <div className="search-text-group">
      <input type="text" placeholder="Search" />
      <button className="btn-search-text">SEARCH TEXT</button>
    </div>
  );
};

export default SearchText;
