import React from 'react';
import './PickCategory.css';

const PickCategory = () => {
  return (
    <div className="pick-category-group">
      <select>
        <option>Pick category</option>
      </select>
      <button className="btn-pick-category">SELECT</button>
    </div>
  );
};

export default PickCategory;
