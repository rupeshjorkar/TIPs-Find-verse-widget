import React from "react";
import './VerseRelatedStory.css'


const VerseRelatedStory = ({verseSlug}) => {
    if (!verseSlug) return null;
 return(
    <>
     <div>{verseSlug}</div>
    </>
 )
}

export default VerseRelatedStory;