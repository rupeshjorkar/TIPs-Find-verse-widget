import React from 'react';
import './VerseListing.css';

const VerseListing = ({ verseData, onVerseClick }) => {
    if (!verseData) return null;

    if (verseData[0]?.error) {
        return <div className='find_ver_error'>{verseData[0]?.error}</div>;
    }

    return (
        <div className="container book-container">
            {verseData.map((chapter, index) => (
                <div key={index} className="book" id='find_verse'>
                    {/* <h3 className="chapter-title">{chapter.chapter_reference}</h3> */}
                        {chapter.verse_slug && Object.entries(chapter.verse_slug).map(([verseRef, verseSlug]) => (
                            <div
                                key={verseRef}
                                id={verseSlug}
                                className="verses"
                            >
                                <span
                                    onClick={() => onVerseClick(verseSlug)}
                                >{verseRef}</span>
                            </div>
                        ))}
                </div>
            ))}
        </div>
    );
};

export default VerseListing;