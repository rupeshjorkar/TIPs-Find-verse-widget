const BASE_URL = 'https://tips.translation.bible/wp-json/v1/bible';

const tipsApi = {
	// Verse Listing Page API
	findVerse: async (verse) => {
		try {
			const res = await fetch(`${BASE_URL}/find-verse/?verse=${encodeURIComponent(verse)}`);
			if (!res.ok) throw new Error(`Error ${res.status}: Failed to fetch verse`);
			return await res.json();
		} catch (error) {
			console.error('findVerse error:', error);
			return { error: error.message };
		}
	},

	// Fetch related story by verse slug
	fetchVerseRelatedStory: async (verseSlug) => {
		try {
			const res = await fetch(`${BASE_URL}/tip_verse?verseId=${encodeURIComponent(verseSlug)}`);
			if (!res.ok) throw new Error(`Error ${res.status}: Failed to fetch related story`);
			return await res.json();
		} catch (error) {
			console.error('fetchVerseRelatedStory error:', error);
			return { error: error.message };
		}
	}

}

export default tipsApi;